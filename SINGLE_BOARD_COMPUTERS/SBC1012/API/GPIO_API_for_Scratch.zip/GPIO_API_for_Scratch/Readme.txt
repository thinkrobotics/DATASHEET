Setup Scratch GPIO environment

* Install 
    sh ./setup.sh
* Uninstall
    sh ./uninstall.sh
