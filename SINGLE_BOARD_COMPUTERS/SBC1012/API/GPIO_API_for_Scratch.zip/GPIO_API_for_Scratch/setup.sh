sudo cp -Rf ./scratchgpio7 /
cp -Rf scratchgpio7.desktop ~/Desktop/
cp -Rf scratchgpio7plus.desktop ~/Desktop/
rm -rf ~/Documents/Scratch\ Projects/
mkdir ~/Documents/Scratch\ Projects/
cp example/* ~/Documents/Scratch\ Projects/
