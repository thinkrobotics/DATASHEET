sudo rm -rf /scratchgpio7 
rm -rf ~/Desktop/scratchgpio7.desktop
rm -rf ~/Desktop/scratchgpio7plus.desktop
rm -rf ~/Documents/Scratch\ Projects/
rm -rf ~/Documents/Scratch\ Projects/
